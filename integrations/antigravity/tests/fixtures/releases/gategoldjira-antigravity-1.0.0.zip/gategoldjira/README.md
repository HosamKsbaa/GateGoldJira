# GateGoldJira for Antigravity

Native Antigravity plugin with a sidecar panel, all published GateGoldJira MCP
tools, and browser OAuth under each person's own account. Requires Antigravity
with sidecar web UI support (the same interface used by HDM Flutter Studio) and
Node.js 22.18 or newer. The package bundles its MCP dependency; users do not run
npm or copy personal tokens.

## Install

Extract the release archive, open its `gategoldjira` directory and run:

```sh
node install.mjs
```

Reload Antigravity. Open **GateGoldJira** from the auxiliary side panel, check
the server settings and choose **Sign in with browser**. Approve with your own
GateGoldJira account. If the browser blocks the popup, use **Continue sign-in in
your browser**. The installed plugin is also listed under Customizations.

Local defaults are website `http://localhost:4201` and MCP
`http://localhost:21080/mcp`. Localhost means this user's computer. For a shared
deployment, install with its actual addresses or save them in the panel:

```sh
node install.mjs --endpoint https://api.example.com/mcp --website https://jira.example.com
```

The installer creates `~/.gemini/config/plugins/gategoldjira`, enables only
`gategoldjira/studio`, and removes duplicate GateGoldJira entries from the known
MCP configs. Other servers and settings are preserved. Private backups and a
restore manifest are kept under `~/.gemini/gategoldjira-backups`. Use the installer
rather than copying the distribution folder: it records absolute executable and
bridge paths for this workstation. Sidecar UI availability depends on the host;
the MCP bridge can run in other stdio MCP hosts after this local profile has been connected through the panel.

## Accounts and privacy

The panel and AI tools share one account per operating-system user profile.
Private connection state is outside the plugin in `~/.gemini/gategoldjira`
(directory 0700, credential files 0600 on Unix). Credentials are stored locally,
not in the OS keychain. Do not share this directory or a single OS profile with
different people. `GATEGOLDJIRA_DATA_DIR` can select a separate private profile.
No password, bearer token or refresh token is placed in MCP configuration or
returned to the panel. The browser callback listens on an ephemeral IP loopback
port and checks PKCE, state, issuer and the exact resource. Cross-process refresh
is serialized because refresh tokens rotate. Access lasts 15 minutes; refresh is
automatic within a 30-day authorization window. After expiry or revocation, sign
in again.

Disconnect revokes the connection on the server before removing its local
credentials. If the server is offline, retry later or revoke from
**Account → MCP connections**. Cancel closes a pending local sign-in. To change
accounts or servers, disconnect first. Tool authorization and the durable activity
history remain authoritative on the Go backend. The panel links to that history;
it does not grant MCP credentials access to REST account-management endpoints.

## Shared server configuration

This repository has not been deployed. The local username/password adapter stays
loopback-only. A shared deployment must use HTTPS for its canonical API, MCP and
website URLs, configure the existing browser OIDC identity provider and approved
company accounts, and set `MCP_BROWSER_OAUTH_ENABLED=true`. The broker uses those
verified browser identities for consent and issues MCP-only credentials. It does
not enable development password fixtures in production. Changing localhost to a
LAN address is not sufficient. No cloud resources or marketplace listing are
created by this plugin.

## Develop and verify

From `integrations/antigravity`, run `npm ci`, `npm run typecheck`, `npm test`, and
`npm run build`. The build copies the generated backend MCP catalog and bundles
the pinned official MCP TypeScript SDK. The host supplies `sidecar_sdk` at runtime;
the plugin does not redistribute or replace it. Run
`scripts/test-antigravity-plugin.sh` from the repository for the isolated real
browser, account-switching and MCP acceptance test. No real OAuth cache is reused.
